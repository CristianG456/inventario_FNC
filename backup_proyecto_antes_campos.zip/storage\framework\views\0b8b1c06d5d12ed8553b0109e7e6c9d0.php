<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>


<?php if(isset($alertasRojas) && $alertasRojas->count() > 0): ?>
<div class="alert alert-danger d-flex align-items-center mb-4 licencia-alerta" role="alert">
    <i class="bi bi-exclamation-octagon-fill fs-4 me-3"></i>
    <div>
        <strong>¡Atención!</strong> Hay <?php echo e($alertasRojas->count()); ?> licencia(s) vencida(s). <a href="<?php echo e(route('licencias.index', ['estado' => 'Vencida'])); ?>" class="alert-link">Ver licencias</a>.
    </div>
</div>
<?php endif; ?>

<?php if(isset($alertasAmarillas) && $alertasAmarillas->count() > 0): ?>
<div class="alert alert-warning d-flex align-items-center mb-4 licencia-alerta" role="alert">
    <i class="bi bi-exclamation-triangle-fill fs-4 me-3"></i>
    <div>
        <strong>Aviso:</strong> Hay <?php echo e($alertasAmarillas->count()); ?> licencia(s) por vencer en los próximos 30 días. <a href="<?php echo e(route('licencias.index')); ?>" class="alert-link">Revisar licencias</a>.
    </div>
</div>
<?php endif; ?>

<div class="row g-4 mb-4">
    
    <div class="col-sm-6 col-xl-3">
        <div class="card p-4 text-center border-start border-primary border-4">
            <div class="fs-1 fw-bold text-primary"><?php echo e($totalEquipos); ?></div>
            <div class="text-muted mt-1"><i class="bi bi-laptop me-1"></i>Total de Equipos</div>
        </div>
    </div>
    
    <div class="col-sm-6 col-xl-3">
        <div class="card p-4 text-center border-start border-success border-4">
            <div class="fs-1 fw-bold text-success"><?php echo e($activos); ?></div>
            <div class="text-muted mt-1"><i class="bi bi-check-circle me-1"></i>Activos</div>
        </div>
    </div>
    
    <div class="col-sm-6 col-xl-3">
        <div class="card p-4 text-center border-start border-warning border-4">
            <div class="fs-1 fw-bold text-warning"><?php echo e($enMantenimiento); ?></div>
            <div class="text-muted mt-1"><i class="bi bi-tools me-1"></i>En Mantenimiento</div>
        </div>
    </div>
    
    <div class="col-sm-6 col-xl-3">
        <div class="card p-4 text-center border-start border-danger border-4">
            <div class="fs-1 fw-bold text-danger"><?php echo e($deBaja); ?></div>
            <div class="text-muted mt-1"><i class="bi bi-x-circle me-1"></i>De Baja</div>
        </div>
    </div>
</div>

<div class="row g-4">
    
    <div class="col-lg-5">
        <div class="card h-100">
            <div class="card-header bg-white fw-semibold border-0 pt-4 px-4">
                <i class="bi bi-pie-chart me-2 text-primary"></i>Equipos por Tipo
            </div>
            <div class="card-body px-4">
                <?php $__empty_1 = true; $__currentLoopData = $equiposPorTipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mb-1">
                            <span class="fw-medium"><?php echo e($tipo->nombre); ?></span>
                            <span class="badge bg-primary rounded-pill"><?php echo e($tipo->equipos_count); ?></span>
                        </div>
                        <div class="progress dashboard-progress-bar">
                            <div class="progress-bar"
                                 style="width: <?php echo e($totalEquipos > 0 ? ($tipo->equipos_count / $totalEquipos * 100) : 0); ?>%">
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">Sin tipos de recurso registrados.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="col-lg-7">
        <div class="card h-100">
            <div class="card-header bg-white fw-semibold border-0 pt-4 px-4 d-flex justify-content-between align-items-center">
                <span><i class="bi bi-clock-history me-2 text-primary"></i>Últimos Equipos Registrados</span>
                <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-sm btn-outline-primary">Ver todos</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Equipo</th>
                                <th>Tipo</th>
                                <th>Usuario</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $ultimosEquipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $equipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td>
                                        <a href="<?php echo e(route('equipos.show', $equipo)); ?>" class="text-decoration-none fw-medium">
                                            <?php echo e($equipo->nombre_equipo); ?>

                                        </a>
                                        <br><small class="text-muted"><?php echo e($equipo->serial); ?></small>
                                    </td>
                                    <td><?php echo e($equipo->tipoRecurso?->nombre ?? '—'); ?></td>
                                    <td><?php echo e($equipo->usuarioAsignado?->nombre ?? '—'); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($equipo->estado_badge); ?>">
                                            <?php echo e($equipo->estado_label); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="4" class="text-center text-muted py-4">Sin equipos registrados.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    setTimeout(function() {
        const alertas = document.querySelectorAll('.licencia-alerta');
        alertas.forEach(alerta => {
            alerta.style.transition = "opacity 0.5s ease";
            alerta.style.opacity = "0";
            setTimeout(() => alerta.remove(), 500);
        });
    }, 40000);
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\dashboard.blade.php ENDPATH**/ ?>