<?php $__env->startSection('title', 'Asignaciones'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
        <i class="bi bi-person-fill-gear me-2 text-primary"></i>Historial de Asignaciones
    </h4>
</div>


<div class="card mb-4 border-0 shadow-sm">
    <div class="card-body py-3">
        <form method="GET" action="<?php echo e(route('asignaciones.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-5">
                <label class="form-label fw-medium small mb-1">Buscar</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>"
                           class="form-control" placeholder="Nombre, cédula, equipo, serial...">
                </div>
            </div>
            <div class="col-md-3">
                <label class="form-label fw-medium small mb-1">Tipo de acción</label>
                <select name="tipo_accion" class="form-select">
                    <option value="">Todos</option>
                    <?php $__currentLoopData = $tiposAccion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e(request('tipo_accion') === $key ? 'selected' : ''); ?>>
                            <?php echo e($label); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-primary flex-fill">
                    <i class="bi bi-funnel me-1"></i>Filtrar
                </button>
                <a href="<?php echo e(route('asignaciones.index')); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-counterclockwise"></i>
                </a>
            </div>
        </form>
    </div>
</div>


<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Equipo</th>
                        <th>Usuario Asignado</th>
                        <th>Tipo Acción</th>
                        <th>Fecha</th>
                        <th>Registrado por</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-muted small"><?php echo e($asignacion->id); ?></td>
                            <td>
                                <span class="fw-medium"><?php echo e($asignacion->equipo?->nombre_equipo ?? '—'); ?></span>
                                <br><small class="text-muted font-monospace"><?php echo e($asignacion->equipo?->serial ?? ''); ?></small>
                            </td>
                            <td>
                                <?php if($asignacion->usuario_nombre): ?>
                                    <?php echo e($asignacion->usuario_nombre); ?>

                                    <br><small class="text-muted">CC: <?php echo e($asignacion->usuario_cedula); ?></small>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($asignacion->tipo_accion_color); ?>">
                                    <?php echo e($asignacion->tipo_accion_label); ?>

                                </span>
                            </td>
                            <td>
                                <span class="small"><?php echo e($asignacion->fecha_accion?->format('d/m/Y H:i') ?? '—'); ?></span>
                            </td>
                            <td class="small text-muted"><?php echo e($asignacion->registradoPor?->name ?? '—'); ?></td>
                            <td class="text-center">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('asignaciones.show', $asignacion)); ?>"
                                       class="btn btn-outline-info" title="Ver detalle">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <?php if(in_array($asignacion->tipo_accion, ['asignacion','reemplazo'])): ?>
                                    <a href="<?php echo e(route('asignaciones.pdf', $asignacion)); ?>"
                                       class="btn btn-outline-danger" title="Descargar PDF">
                                        <i class="bi bi-file-pdf"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                                No hay registros de asignaciones.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($asignaciones->hasPages()): ?>
        <div class="card-footer bg-white border-0 d-flex justify-content-between align-items-center">
            <small class="text-muted">
                Mostrando <?php echo e($asignaciones->firstItem()); ?>–<?php echo e($asignaciones->lastItem()); ?> de <?php echo e($asignaciones->total()); ?>

            </small>
            <?php echo e($asignaciones->links('pagination::bootstrap-5')); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\asignaciones\index.blade.php ENDPATH**/ ?>