

<?php $__env->startSection('title', 'Detalle Checklist'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
        <i class="bi bi-clipboard-check me-2 text-info"></i>Detalle de Checklist
    </h4>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('checklists.edit', $checklist)); ?>" class="btn btn-warning text-white">
            <i class="bi bi-pencil me-1"></i>Editar
        </a>
        <a href="<?php echo e(route('checklists.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<div class="card config-card-medium">
    <div class="card-body">
        <dl class="row mb-0">
            <dt class="col-sm-4 text-muted">Equipo</dt>
            <dd class="col-sm-8">
                <?php if($checklist->equipo): ?>
                    <a href="<?php echo e(route('equipos.show', $checklist->equipo)); ?>">
                        <?php echo e($checklist->equipo->nombre_equipo); ?>

                    </a>
                    <span class="text-muted ms-2">(<?php echo e($checklist->equipo->serial); ?>)</span>
                <?php else: ?>
                    —
                <?php endif; ?>
            </dd>
            <dt class="col-sm-4 text-muted">Responsable TI</dt>
            <dd class="col-sm-8"><?php echo e($checklist->responsable_ti ?? '—'); ?></dd>
            <dt class="col-sm-4 text-muted">Orden de Trabajo</dt>
            <dd class="col-sm-8"><?php echo e($checklist->orden_trabajo ?? '—'); ?></dd>
            <dt class="col-sm-4 text-muted">Cruce AV</dt>
            <dd class="col-sm-8"><?php echo e($checklist->cruce_av ?? '—'); ?></dd>
            <dt class="col-sm-4 text-muted">Cruce Short name</dt>
            <dd class="col-sm-8"><?php echo e($checklist->crece_software ?? '—'); ?></dd>
            <dt class="col-sm-4 text-muted">Resultado Cruce Antivirus</dt>
            <dd class="col-sm-8"><?php echo e($checklist->resultado ?? '—'); ?></dd>
            <dt class="col-sm-4 text-muted">Tipo Aprobado</dt>
            <dd class="col-sm-8"><?php echo e($checklist->tipo_aprobado ?? '—'); ?></dd>
            <dt class="col-sm-4 text-muted">FNC</dt>
            <dd class="col-sm-8"><?php echo e($checklist->fnc ?? '—'); ?></dd>
            <dt class="col-sm-4 text-muted">Observaciones</dt>
            <dd class="col-sm-8"><?php echo e($checklist->observaciones ?? '—'); ?></dd>
            <dt class="col-sm-4 text-muted">Registrado el</dt>
            <dd class="col-sm-8"><?php echo e($checklist->created_at->format('d/m/Y H:i')); ?></dd>
        </dl>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\checklists\show.blade.php ENDPATH**/ ?>