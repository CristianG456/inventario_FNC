<?php $__env->startSection('title', 'Detalle — Evento Técnico'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">
            <i class="bi <?php echo e($historialTecnico->tipo_evento_icono); ?> me-2 text-<?php echo e($historialTecnico->tipo_evento_color); ?>"></i>
            <?php echo e($historialTecnico->tipo_evento_label); ?>

        </h4>
        <small class="text-muted">
            <?php echo e($historialTecnico->equipo?->nombre_equipo); ?> — <?php echo e($historialTecnico->fecha_evento?->format('d/m/Y')); ?>

        </small>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('historial-tecnico.edit', $historialTecnico)); ?>" class="btn btn-warning text-white">
            <i class="bi bi-pencil me-1"></i>Editar
        </a>
        <a href="<?php echo e(route('historial-tecnico.por-equipo', $historialTecnico->equipo_id)); ?>"
           class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Historial del Equipo
        </a>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-<?php echo e($historialTecnico->tipo_evento_color); ?> bg-opacity-10 fw-semibold border-0 py-3">
                <i class="bi <?php echo e($historialTecnico->tipo_evento_icono); ?> me-2 text-<?php echo e($historialTecnico->tipo_evento_color); ?>"></i>
                Detalle del Evento
            </div>
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-sm-4 text-muted">Tipo de Evento</dt>
                    <dd class="col-sm-8">
                        <span class="badge bg-<?php echo e($historialTecnico->tipo_evento_color); ?>">
                            <?php echo e($historialTecnico->tipo_evento_label); ?>

                        </span>
                    </dd>
                    <dt class="col-sm-4 text-muted">Descripción</dt>
                    <dd class="col-sm-8"><?php echo e($historialTecnico->descripcion); ?></dd>
                    <?php if($historialTecnico->motivo): ?>
                    <dt class="col-sm-4 text-muted">Motivo</dt>
                    <dd class="col-sm-8"><?php echo e($historialTecnico->motivo); ?></dd>
                    <?php endif; ?>
                    <dt class="col-sm-4 text-muted">Fecha del Evento</dt>
                    <dd class="col-sm-8"><?php echo e($historialTecnico->fecha_evento?->format('d \d\e F \d\e Y')); ?></dd>
                    <dt class="col-sm-4 text-muted">Técnico Responsable</dt>
                    <dd class="col-sm-8 fw-bold"><?php echo e($historialTecnico->usuario_responsable); ?></dd>
                    <?php if($historialTecnico->observaciones): ?>
                    <dt class="col-sm-4 text-muted">Observaciones</dt>
                    <dd class="col-sm-8"><?php echo e($historialTecnico->observaciones); ?></dd>
                    <?php endif; ?>
                    <dt class="col-sm-4 text-muted">Registrado por</dt>
                    <dd class="col-sm-8"><?php echo e($historialTecnico->registradoPor?->name ?? '—'); ?></dd>
                    <dt class="col-sm-4 text-muted">Fecha de Registro</dt>
                    <dd class="col-sm-8"><?php echo e($historialTecnico->created_at?->format('d/m/Y H:i')); ?></dd>
                </dl>

                
                <?php if($historialTecnico->archivos && count($historialTecnico->archivos) > 0): ?>
                <hr>
                <h6 class="fw-bold mb-3"><i class="bi bi-paperclip me-1"></i>Archivos Adjuntos</h6>
                <div class="d-flex flex-wrap gap-2">
                    <?php $__currentLoopData = $historialTecnico->archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(asset('storage/' . $archivo['ruta'])); ?>"
                       target="_blank"
                       class="btn btn-outline-secondary">
                        <i class="bi bi-file-earmark me-1"></i><?php echo e($archivo['nombre']); ?>

                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-success bg-opacity-10 fw-semibold border-0 py-3">
                <i class="bi bi-person-check me-2 text-success"></i>Usuario en ese Momento
            </div>
            <div class="card-body">
                <?php if($historialTecnico->usuario_asignado_snapshot): ?>
                <?php $snap = $historialTecnico->usuario_asignado_snapshot; ?>
                <dl class="row mb-0 small">
                    <dt class="col-5 text-muted">Nombre</dt>
                    <dd class="col-7 fw-bold"><?php echo e($snap['nombre'] ?? '—'); ?></dd>
                    <dt class="col-5 text-muted">Cédula</dt>
                    <dd class="col-7"><?php echo e($snap['cedula'] ?? '—'); ?></dd>
                    <dt class="col-5 text-muted">Cargo</dt>
                    <dd class="col-7"><?php echo e($snap['cargo'] ?? '—'); ?></dd>
                    <dt class="col-5 text-muted">Área</dt>
                    <dd class="col-7"><?php echo e($snap['area'] ?? '—'); ?></dd>
                    <dt class="col-5 text-muted">Dependencia</dt>
                    <dd class="col-7"><?php echo e($snap['dependencia'] ?? '—'); ?></dd>
                    <?php if(!empty($snap['distrito'])): ?>
                    <dt class="col-5 text-muted">Distrito</dt>
                    <dd class="col-7"><?php echo e($snap['distrito']); ?></dd>
                    <?php endif; ?>
                    <?php if(!empty($snap['seccional'])): ?>
                    <dt class="col-5 text-muted">Seccional</dt>
                    <dd class="col-7"><?php echo e($snap['seccional']); ?></dd>
                    <?php endif; ?>
                </dl>
                <?php else: ?>
                <p class="text-muted mb-0 small">No se registró usuario asignado en este momento.</p>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="card border-0 shadow-sm mt-3">
            <div class="card-header bg-primary bg-opacity-10 fw-semibold border-0 py-3">
                <i class="bi bi-laptop me-2 text-primary"></i>Equipo
            </div>
            <div class="card-body">
                <dl class="row mb-0 small">
                    <dt class="col-5 text-muted">Nombre</dt>
                    <dd class="col-7 fw-bold"><?php echo e($historialTecnico->equipo?->nombre_equipo); ?></dd>
                    <dt class="col-5 text-muted">Serial</dt>
                    <dd class="col-7 font-monospace"><?php echo e($historialTecnico->equipo?->serial); ?></dd>
                    <?php if($historialTecnico->equipo?->activo_fijo): ?>
                    <dt class="col-5 text-muted">Activo Fijo</dt>
                    <dd class="col-7"><?php echo e($historialTecnico->equipo->activo_fijo); ?></dd>
                    <?php endif; ?>
                </dl>
                <a href="<?php echo e(route('equipos.show', $historialTecnico->equipo_id)); ?>"
                   class="btn btn-sm btn-outline-primary mt-2 w-100">
                    <i class="bi bi-eye me-1"></i>Ver Equipo
                </a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\historial_tecnico\show.blade.php ENDPATH**/ ?>