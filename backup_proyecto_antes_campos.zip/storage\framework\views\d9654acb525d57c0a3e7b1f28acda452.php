<?php $__env->startSection('title', 'Asignaciones de Licencias'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0"><i class="bi bi-list-check me-2 text-primary"></i>Asignaciones de Licencias</h4>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('licencias.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Catálogo de Licencias
        </a>
        <a href="<?php echo e(route('licencia-asignaciones.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i>Nueva Asignación
        </a>
    </div>
</div>


<div class="card mb-4">
    <div class="card-body py-3">
        <form method="GET" action="<?php echo e(route('licencia-asignaciones.index')); ?>" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label fw-medium small mb-1">Estado</label>
                <select name="estado" class="form-select">
                    <option value="">Todos</option>
                    <option value="Activa" <?php echo e(request('estado') === 'Activa' ? 'selected' : ''); ?>>Activa</option>
                    <option value="Vencida" <?php echo e(request('estado') === 'Vencida' ? 'selected' : ''); ?>>Vencida</option>
                    <option value="Retirada" <?php echo e(request('estado') === 'Retirada' ? 'selected' : ''); ?>>Retirada</option>
                    <option value="Suspendida" <?php echo e(request('estado') === 'Suspendida' ? 'selected' : ''); ?>>Suspendida</option>
                </select>
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-primary flex-fill">
                    <i class="bi bi-funnel me-1"></i>Filtrar
                </button>
                <a href="<?php echo e(route('licencia-asignaciones.index')); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-counterclockwise"></i>
                </a>
            </div>
        </form>
    </div>
</div>


<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Licencia</th>
                        <th>Funcionario</th>
                        <th>Equipo</th>
                        <th>Fechas</th>
                        <th>Estado</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-muted small"><?php echo e($asignacion->id); ?></td>
                            <td>
                                <?php if($asignacion->licencia): ?>
                                    <a href="<?php echo e(route('licencias.show', $asignacion->licencia)); ?>" class="fw-medium text-decoration-none">
                                        <?php echo e($asignacion->licencia->nombre); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="text-muted">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo e($asignacion->funcionario ? $asignacion->funcionario->nombre_completo : 'N/A'); ?>

                            </td>
                            <td>
                                <?php if($asignacion->equipo): ?>
                                    <a href="<?php echo e(route('equipos.show', $asignacion->equipo)); ?>" class="text-decoration-none fw-medium">
                                        <?php echo e($asignacion->equipo->placa ?? $asignacion->equipo->nombre_equipo ?? 'Ver Equipo'); ?>

                                    </a><br>
                                    <span class="text-muted small">Serial: <?php echo e($asignacion->equipo->serial ?? 'N/A'); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">N/A</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <small class="text-muted">Asignada:</small> <?php echo e($asignacion->fecha_asignacion ? $asignacion->fecha_asignacion->format('d/m/Y') : 'N/A'); ?><br>
                                <small class="text-muted">Vence:</small> <strong class="<?php echo e($asignacion->fecha_vencimiento && $asignacion->fecha_vencimiento->isPast() ? 'text-danger' : ''); ?>"><?php echo e($asignacion->fecha_vencimiento ? $asignacion->fecha_vencimiento->format('d/m/Y') : 'N/A'); ?></strong>
                            </td>
                            <td>
                                <span class="badge bg-<?php echo e($asignacion->estado === 'Activa' ? 'success' : ($asignacion->estado === 'Vencida' ? 'danger' : 'secondary')); ?>">
                                    <?php echo e($asignacion->estado); ?>

                                </span>
                            </td>
                            <td class="text-center">
                                <div class="d-flex gap-1 justify-content-center flex-wrap">
                                    <a href="<?php echo e(route('licencia-asignaciones.edit', $asignacion)); ?>" class="btn btn-sm btn-outline-warning" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <button type="button" class="btn btn-sm btn-outline-danger" title="Eliminar"
                                            data-delete-url="<?php echo e(route('licencia-asignaciones.destroy', $asignacion)); ?>"
                                            data-delete-name="Asignación ID <?php echo e($asignacion->id); ?>">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                                No hay asignaciones registradas.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($asignaciones->hasPages()): ?>
        <div class="card-footer bg-white border-0 d-flex justify-content-between align-items-center">
            <small class="text-muted">
                Mostrando <?php echo e($asignaciones->firstItem()); ?>–<?php echo e($asignaciones->lastItem()); ?> de <?php echo e($asignaciones->total()); ?> asignaciones
            </small>
            <?php echo e($asignaciones->links('pagination::bootstrap-5')); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\licencias_asignaciones\index.blade.php ENDPATH**/ ?>