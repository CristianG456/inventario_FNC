<?php $__env->startSection('title', 'Editar Evento Técnico'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
        <i class="bi bi-pencil me-2 text-warning"></i>Editar Evento Técnico
    </h4>
    <a href="<?php echo e(route('historial-tecnico.show', $historialTecnico)); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i>Volver
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?php echo e(route('historial-tecnico.update', $historialTecnico)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label fw-medium">Equipo</label>
                    <input type="hidden" name="equipo_id" value="<?php echo e($historialTecnico->equipo_id); ?>">
                    <input type="text" class="form-control" readonly
                           value="<?php echo e($historialTecnico->equipo?->nombre_equipo); ?> (<?php echo e($historialTecnico->equipo?->serial); ?>)">
                </div>

                <div class="col-md-6">
                    <label for="tipo_evento" class="form-label fw-medium">
                        Tipo de Evento <span class="text-danger">*</span>
                    </label>
                    <select name="tipo_evento" id="tipo_evento"
                            class="form-select <?php $__errorArgs = ['tipo_evento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__currentLoopData = $tiposEvento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>"
                                <?php echo e(old('tipo_evento', $historialTecnico->tipo_evento) === $key ? 'selected' : ''); ?>>
                                <?php echo e($label); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['tipo_evento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                    <label for="descripcion" class="form-label fw-medium">
                        Descripción <span class="text-danger">*</span>
                    </label>
                    <input type="text" name="descripcion" id="descripcion"
                           class="form-control <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('descripcion', $historialTecnico->descripcion)); ?>"
                           required maxlength="500">
                    <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-6">
                    <label for="motivo" class="form-label fw-medium">Motivo</label>
                    <input type="text" name="motivo" id="motivo"
                           class="form-control"
                           value="<?php echo e(old('motivo', $historialTecnico->motivo)); ?>" maxlength="500">
                </div>

                <div class="col-md-3">
                    <label for="fecha_evento" class="form-label fw-medium">
                        Fecha del Evento <span class="text-danger">*</span>
                    </label>
                    <input type="date" name="fecha_evento" id="fecha_evento"
                           class="form-control <?php $__errorArgs = ['fecha_evento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('fecha_evento', $historialTecnico->fecha_evento?->format('Y-m-d'))); ?>"
                           max="<?php echo e(date('Y-m-d')); ?>" required>
                    <?php $__errorArgs = ['fecha_evento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-md-3">
                    <label for="usuario_responsable" class="form-label fw-medium">
                        Técnico Responsable <span class="text-danger">*</span>
                    </label>
                    <input type="text" name="usuario_responsable" id="usuario_responsable"
                           class="form-control <?php $__errorArgs = ['usuario_responsable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           value="<?php echo e(old('usuario_responsable', $historialTecnico->usuario_responsable)); ?>"
                           maxlength="150" required>
                    <?php $__errorArgs = ['usuario_responsable'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-12">
                    <label for="observaciones" class="form-label fw-medium">Observaciones</label>
                    <textarea name="observaciones" id="observaciones" rows="3"
                              class="form-control"><?php echo e(old('observaciones', $historialTecnico->observaciones)); ?></textarea>
                </div>
            </div>

            <hr class="my-4">

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-warning text-white">
                    <i class="bi bi-check-lg me-1"></i>Actualizar Evento
                </button>
                <a href="<?php echo e(route('historial-tecnico.show', $historialTecnico)); ?>"
                   class="btn btn-outline-secondary">Cancelar</a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\historial_tecnico\edit.blade.php ENDPATH**/ ?>