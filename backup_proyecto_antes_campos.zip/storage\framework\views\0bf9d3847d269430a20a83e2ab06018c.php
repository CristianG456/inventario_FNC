<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Inventario TIC'); ?> &mdash; Federación Nacional de Cafeteros</title>
    
    <link rel="icon" type="image/png" href="<?php echo e(asset('imagenes/federacion cafeteros logo.png')); ?>">
    
    <!-- Google Fonts: Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css']); ?>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<nav id="sidebar">
    <div class="sidebar-brand">
        <img src="<?php echo e(asset('imagenes/federacion cafeteros logo.png')); ?>" alt="Logo FNC">
        <div class="brand-text">
            <span class="brand-title">Inventario TIC</span>
            <span class="brand-subtitle">Tolima</span>
        </div>
    </div>
    
    <div class="nav-menu">
        <ul class="nav flex-column">
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.ver')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('equipos.ver')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('equipos.index')); ?>" class="nav-link <?php echo e(request()->routeIs('equipos.*') ? 'active' : ''); ?>">
                    <i class="bi bi-display"></i> Activos
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuarios.ver')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('funcionarios.index')); ?>" class="nav-link <?php echo e(request()->routeIs('funcionarios.*') ? 'active' : ''); ?>">
                    <i class="bi bi-people"></i> Funcionarios
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('mesaayuda.ver')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('tickets.index')); ?>" class="nav-link <?php echo e(request()->routeIs('tickets.*') ? 'active' : ''); ?>">
                    <i class="bi bi-headset"></i> HelpDesk
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('historial.ver')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('historial-tecnico.index')); ?>" class="nav-link <?php echo e(request()->routeIs('historial-tecnico.*') ? 'active' : ''); ?>">
                    <i class="bi bi-tools"></i> Mantenimientos
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('configuracion.editar')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('tipo-recursos.index')); ?>" class="nav-link <?php echo e(request()->routeIs('tipo-recursos.*') ? 'active' : ''); ?>">
                    <i class="bi bi-tags"></i> Categorías
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('licencias.ver')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('licencias.index')); ?>" class="nav-link <?php echo e(request()->routeIs('licencias.*') || request()->routeIs('licencia-asignaciones.*') ? 'active' : ''); ?>">
                    <i class="bi bi-key"></i> Licencias
                </a>
            </li>
            <?php endif; ?>

            <li class="nav-item">
                <a href="<?php echo e(route('suscripciones.index')); ?>" class="nav-link <?php echo e(request()->routeIs('suscripciones.*') || request()->routeIs('suscripcion-asignaciones.*') ? 'active' : ''); ?>">
                    <i class="bi bi-calendar-check"></i> Suscripciones
                </a>
            </li>

            <li class="nav-item">
                <a href="<?php echo e(route('vitalicias.index')); ?>" class="nav-link <?php echo e(request()->routeIs('vitalicias.*') || request()->routeIs('vitalicia-asignaciones.*') ? 'active' : ''); ?>">
                    <i class="bi bi-award"></i> Vitalicias
                </a>
            </li>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('dashboard.ver')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('reportes.index')); ?>" class="nav-link <?php echo e(request()->routeIs('reportes.*') ? 'active' : ''); ?>">
                    <i class="bi bi-file-earmark-bar-graph"></i> Reportes
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('configuracion.editar')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('plantillas-pdf.index')); ?>" class="nav-link <?php echo e(request()->routeIs('plantillas-pdf.*') ? 'active' : ''); ?>">
                    <i class="bi bi-file-earmark-check"></i> Actas
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('equipos.ver')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('actas-firmadas.index')); ?>" class="nav-link <?php echo e(request()->routeIs('actas-firmadas.*') ? 'active' : ''); ?>">
                    <i class="bi bi-file-earmark-pdf"></i> Actas Firmadas
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('equipos.importar')): ?>
            <li class="nav-item">
                <a href="<?php echo e(route('equipos.importar.form')); ?>" class="nav-link <?php echo e(request()->routeIs('equipos.importar*') ? 'active' : ''); ?>">
                    <i class="bi bi-upload"></i> Importar
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles.ver')): ?>
            <li class="nav-item mt-3 mb-1 px-3 text-uppercase text-muted text-xs font-weight-bold">Seguridad</li>
            <li class="nav-item">
                <a href="<?php echo e(route('usuarios.index')); ?>" class="nav-link <?php echo e(request()->routeIs('usuarios.*') ? 'active' : ''); ?>">
                    <i class="bi bi-person-badge"></i> Usuarios Sistema
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('roles.index')); ?>" class="nav-link <?php echo e(request()->routeIs('roles.*') ? 'active' : ''); ?>">
                    <i class="bi bi-shield-lock"></i> Roles y Permisos
                </a>
            </li>
            <li class="nav-item">
                <a href="<?php echo e(route('auditoria.index')); ?>" class="nav-link <?php echo e(request()->routeIs('auditoria.*') ? 'active' : ''); ?>">
                    <i class="bi bi-journal-text"></i> Auditoría
                </a>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('configuracion.editar')): ?>
            <li class="nav-item">
                <a href="#" class="nav-link <?php echo e(request()->routeIs('backups.*') ? 'active' : ''); ?>">
                    <i class="bi bi-database-down"></i> Backups
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="sidebar-footer">
        <form method="POST" action="<?php echo e(route('logout')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit" class="nav-link btn btn-link text-start w-100 btn-logout">
                <i class="bi bi-box-arrow-left me-2"></i> Cerrar Sesión
            </button>
        </form>
    </div>
</nav>

<div class="main-content">
    <div class="topbar">
        <div class="d-flex align-items-center gap-3">
            <button class="btn btn-light d-md-none" onclick="document.getElementById('sidebar').classList.toggle('show')">
                <i class="bi bi-list"></i>
            </button>
            <div class="topbar-title">
                <h5>Sistema Inventario</h5>
                <span>FEDERACIÓN NACIONAL DE CAFETEROS - TOLIMA</span>
            </div>
        </div>
        
        <div class="user-profile">
            <div class="user-info">
                <span class="user-role"><?php echo e(auth()->user()->roles->first()->name ?? 'Usuario'); ?></span>
                <span class="user-name"><?php echo e(auth()->user()->name ?? 'ADMIN'); ?></span>
            </div>
            <div class="user-avatar">
                <?php echo e(substr(auth()->user()->name ?? 'A', 0, 1)); ?>

            </div>
        </div>
    </div>

    <div class="content-area">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('js/app-core.js')); ?>"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        window.initAlerts(
            <?php echo json_encode(session('success'), 15, 512) ?>,
            <?php echo json_encode(session('error'), 15, 512) ?>,
            <?php echo json_encode(session('warning'), 15, 512) ?>,
            <?php echo json_encode($errors->all(), 15, 512) ?>
        );
    });

    // Auto-capitalizar la primera letra en todos los inputs de texto y textareas
    document.addEventListener('input', function(e) {
        if (e.target.matches('input[type="text"], input[type="search"], textarea')) {
            let val = e.target.value;
            if (val.length > 0 && val[0].match(/[a-z]/)) {
                // Guardar la posición del cursor para no interrumpir la escritura
                let start = e.target.selectionStart;
                let end = e.target.selectionEnd;
                
                e.target.value = val.charAt(0).toUpperCase() + val.slice(1);
                
                // Restaurar la posición del cursor
                e.target.setSelectionRange(start, end);
            }
        }
    });
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /var/www/resources/views/layouts/inventario.blade.php ENDPATH**/ ?>