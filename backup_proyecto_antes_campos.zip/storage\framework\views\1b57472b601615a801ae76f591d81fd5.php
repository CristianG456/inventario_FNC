<?php $__env->startSection('title', 'Historial de Licencias'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0"><i class="bi bi-clock-history me-2 text-primary"></i>Historial de Licencias</h4>
    <a href="<?php echo e(route('licencias.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i>Volver al Catálogo
    </a>
</div>


<div class="card mb-4">
    <div class="card-body py-3">
        <form method="GET" action="<?php echo e(route('licencias.historial')); ?>" class="row g-2 align-items-end">
            <div class="col-md-6">
                <label class="form-label fw-medium small mb-1">Buscar</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-search"></i></span>
                    <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>"
                           class="form-control" placeholder="Licencia, funcionario, equipo o acción...">
                </div>
            </div>
            <div class="col-md-2 d-flex gap-2">
                <button type="submit" class="btn btn-primary flex-fill">
                    <i class="bi bi-funnel me-1"></i>Buscar
                </button>
                <a href="<?php echo e(route('licencias.historial')); ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-counterclockwise"></i>
                </a>
            </div>
        </form>
    </div>
</div>


<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Fecha y Hora</th>
                        <th>Usuario (Responsable)</th>
                        <th>Acción</th>
                        <th>Licencia</th>
                        <th>Funcionario</th>
                        <th>Equipo (Placa)</th>
                        <th>Observación</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <span class="fw-medium"><?php echo e($log->fecha->format('d/m/Y')); ?></span>
                                <br><small class="text-muted"><?php echo e($log->fecha->format('H:i:s')); ?></small>
                            </td>
                            <td><?php echo e($log->usuario ? $log->usuario->name : 'Sistema'); ?></td>
                            <td><span class="badge bg-secondary"><?php echo e($log->accion); ?></span></td>
                            <td><?php echo e($log->licencia_nombre ?? 'N/A'); ?></td>
                            <td><?php echo e($log->funcionario_nombre ?? 'N/A'); ?></td>
                            <td><?php echo e($log->equipo_placa ?? 'N/A'); ?></td>
                            <td class="small text-muted"><?php echo e($log->observacion); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                                No hay registros en el historial.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($historial->hasPages()): ?>
        <div class="card-footer bg-white border-0 d-flex justify-content-between align-items-center">
            <small class="text-muted">
                Mostrando <?php echo e($historial->firstItem()); ?>–<?php echo e($historial->lastItem()); ?> de <?php echo e($historial->total()); ?> registros
            </small>
            <?php echo e($historial->links('pagination::bootstrap-5')); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\licencias_historial\index.blade.php ENDPATH**/ ?>