<?php $__env->startSection('title', 'Gestión de Funcionarios'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <div>
        <h4 class="page-title">Gestión de Funcionarios</h4>
        <p class="page-subtitle">Directorio y control administrativo del personal (<?php echo e($funcionarios->total()); ?> registros)</p>
    </div>
    <a href="<?php echo e(route('funcionarios.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Nuevo Funcionario
    </a>
</div>

<div class="card p-0">
    <div class="p-4 border-bottom border-light">
        <form action="<?php echo e(route('funcionarios.index')); ?>" method="GET" class="d-flex gap-3 align-items-center">
            <div class="search-bar flex-grow-1 funcionario-search-bar">
                <i class="bi bi-search text-muted"></i>
                <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>" placeholder="Busca por nombre, cédula, cargo...">
            </div>
            <button type="button" class="btn btn-outline-secondary rounded-pill px-4">
                <i class="bi bi-funnel me-1"></i> Más Filtros
            </button>
        </form>
    </div>
    
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th class="ps-4">Funcionario</th>
                    <th>Identificación</th>
                    <th>Gestión / Área</th>
                    <th>Vinculación</th>
                    <th>Activos</th>
                    <th class="text-end pe-4">Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $funcionarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $func): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="ps-4 fw-medium"><?php echo e($func->nombres); ?> <?php echo e($func->apellidos); ?></td>
                    <td class="text-muted"><?php echo e($func->identificacion); ?></td>
                    <td>
                        <div><?php echo e($func->cargo ?? '—'); ?></div>
                        <small class="text-muted"><?php echo e($func->area ?? '—'); ?></small>
                    </td>
                    <td>
                        <span class="badge <?php echo e($func->estado == 'Activo' ? 'badge-success' : 'badge-secondary'); ?>">
                            <?php echo e($func->estado); ?>

                        </span>
                    </td>
                    <td>
                        <span class="badge <?php echo e($func->equipos_asignados_count > 0 ? 'bg-primary' : 'bg-light text-dark border'); ?>">
                            <i class="bi bi-laptop me-1"></i> <?php echo e($func->equipos_asignados_count); ?>

                        </span>
                    </td>
                    <td class="text-end pe-4">
                        <button class="btn btn-sm btn-light rounded-circle"><i class="bi bi-eye"></i></button>
                        <button class="btn btn-sm btn-light rounded-circle"><i class="bi bi-pencil"></i></button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center py-5 text-muted">
                        NO SE ENCONTRARON FUNCIONARIOS REGISTRADOS
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($funcionarios->hasPages()): ?>
    <div class="p-3 border-top">
        <?php echo e($funcionarios->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\funcionarios\index.blade.php ENDPATH**/ ?>