<?php $__env->startSection('title', 'Ver Plantilla PDF'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
        <i class="bi bi-file-earmark-pdf me-2 text-danger"></i><?php echo e($plantillasPdf->nombre); ?>

    </h4>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('plantillas-pdf.edit', $plantillasPdf)); ?>" class="btn btn-warning text-white">
            <i class="bi bi-pencil me-1"></i>Editar
        </a>
        <a href="<?php echo e(route('plantillas-pdf.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-8">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-bottom py-3">
                <strong>Contenido de la Plantilla</strong>
                <?php if($plantillasPdf->activa): ?>
                    <span class="badge bg-success ms-2">Activa</span>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <pre class="bg-light p-3 rounded small config-pre-wrap config-scrollable-500"><?php echo e($plantillasPdf->contenido); ?></pre>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-info bg-opacity-10 fw-semibold border-0 py-3">
                <i class="bi bi-braces me-2 text-info"></i>Variables Reconocidas
            </div>
            <div class="card-body p-0">
                <div class="config-scrollable-400">
                    <table class="table table-sm mb-0">
                        <tbody>
                            <?php $__currentLoopData = $variables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $var => $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(str_contains($plantillasPdf->contenido, $var)): ?>
                            <tr class="table-success">
                                <td><code class="small text-success"><?php echo e($var); ?></code></td>
                                <td class="small"><?php echo e($desc); ?></td>
                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/plantillas_pdf/show.blade.php ENDPATH**/ ?>