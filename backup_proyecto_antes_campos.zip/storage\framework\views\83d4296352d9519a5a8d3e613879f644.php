<?php $__env->startSection('title', 'Historial de Asignaciones — ' . $equipo->nombre_equipo); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">
            <i class="bi bi-person-fill-gear me-2 text-primary"></i>Asignaciones del Equipo
        </h4>
        <small class="text-muted"><?php echo e($equipo->nombre_equipo); ?> — Serial: <?php echo e($equipo->serial); ?></small>
    </div>
    <a href="<?php echo e(route('equipos.show', $equipo)); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i>Volver
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Tipo Acción</th>
                        <th>Usuario</th>
                        <th>Área / Distrito</th>
                        <th>Fecha</th>
                        <th>Registrado por</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-muted small"><?php echo e($asignacion->id); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($asignacion->tipo_accion_color); ?>">
                                    <?php echo e($asignacion->tipo_accion_label); ?>

                                </span>
                            </td>
                            <td>
                                <?php if($asignacion->usuario_nombre): ?>
                                    <span class="fw-medium"><?php echo e($asignacion->usuario_nombre); ?></span>
                                    <br><small class="text-muted">CC: <?php echo e($asignacion->usuario_cedula); ?></small>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <small>
                                    <?php echo e($asignacion->usuario_area ?? '—'); ?>

                                    <?php if($asignacion->usuario_distrito): ?>
                                        <br><span class="text-muted"><?php echo e($asignacion->usuario_distrito); ?></span>
                                    <?php endif; ?>
                                </small>
                            </td>
                            <td>
                                <small><?php echo e($asignacion->fecha_accion?->format('d/m/Y H:i') ?? '—'); ?></small>
                            </td>
                            <td class="small text-muted"><?php echo e($asignacion->registradoPor?->name ?? '—'); ?></td>
                            <td class="text-center">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('asignaciones.show', $asignacion)); ?>"
                                       class="btn btn-outline-info" title="Ver detalle">
                                        <i class="bi bi-eye"></i>
                                    </a>
                                    <?php if(in_array($asignacion->tipo_accion, ['asignacion','reemplazo'])): ?>
                                    <a href="<?php echo e(route('asignaciones.pdf', $asignacion)); ?>"
                                       class="btn btn-outline-danger" title="Descargar PDF">
                                        <i class="bi bi-file-pdf"></i>
                                    </a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                                No hay registros de asignaciones para este equipo.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($asignaciones->hasPages()): ?>
        <div class="card-footer bg-white border-0 d-flex justify-content-between align-items-center">
            <small class="text-muted">
                Mostrando <?php echo e($asignaciones->firstItem()); ?>–<?php echo e($asignaciones->lastItem()); ?> de <?php echo e($asignaciones->total()); ?>

            </small>
            <?php echo e($asignaciones->links('pagination::bootstrap-5')); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\asignaciones\por_equipo.blade.php ENDPATH**/ ?>