<?php $__env->startSection('title', 'Mesa de Ayuda'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header mb-4">
    <div>
        <h4 class="page-title">Mesa de Ayuda TIC</h4>
        <p class="page-subtitle">Centro de gestión de incidentes y servicios tecnológicos (<?php echo e($totalTickets); ?> tickets)</p>
    </div>
    <a href="<?php echo e(route('tickets.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i> Nuevo Ticket
    </a>
</div>

<div class="card p-0">
    <div class="p-4 border-bottom border-light">
        <form action="<?php echo e(route('tickets.index')); ?>" method="GET" class="d-flex gap-3 align-items-center">
            <div class="search-bar flex-grow-1 ticket-search-bar">
                <i class="bi bi-search text-muted"></i>
                <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>" placeholder="Busca por título, funcionario o ID...">
            </div>
            
            <div class="search-bar ticket-status-filter">
                <select name="estado" class="form-select border-0 bg-transparent text-muted" onchange="this.form.submit()">
                    <option value="">Cualquier Estado</option>
                    <option value="Abierto" <?php echo e(request('estado') == 'Abierto' ? 'selected' : ''); ?>>Abierto</option>
                    <option value="En Progreso" <?php echo e(request('estado') == 'En Progreso' ? 'selected' : ''); ?>>En Progreso</option>
                    <option value="Resuelto" <?php echo e(request('estado') == 'Resuelto' ? 'selected' : ''); ?>>Resuelto</option>
                </select>
            </div>
        </form>
    </div>
    
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th class="ps-4">Ticket</th>
                    <th>Solicitante</th>
                    <th>Estado</th>
                    <th>Responsable</th>
                    <th>Fecha</th>
                    <th class="text-end pe-4">Detalle</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="ps-4 fw-medium">
                        #<?php echo e(str_pad($ticket->id, 4, '0', STR_PAD_LEFT)); ?><br>
                        <small class="text-muted fw-normal"><?php echo e($ticket->titulo); ?></small>
                    </td>
                    <td>
                        <?php echo e($ticket->funcionario->nombres ?? 'Desconocido'); ?><br>
                        <small class="text-muted"><?php echo e($ticket->funcionario->cargo ?? ''); ?></small>
                    </td>
                    <td>
                        <span class="badge <?php echo e($ticket->estado == 'Abierto' ? 'badge-warning' : 
                            ($ticket->estado == 'Resuelto' ? 'badge-success' : 'badge-info')); ?>"><?php echo e($ticket->estado); ?></span><br>
                        <small class="text-muted"><?php echo e($ticket->prioridad); ?></small>
                    </td>
                    <td class="text-muted"><?php echo e($ticket->responsable->name ?? 'Sin asignar'); ?></td>
                    <td><?php echo e($ticket->created_at->format('d M Y')); ?></td>
                    <td class="text-end pe-4">
                        <button class="btn btn-sm btn-light rounded-circle"><i class="bi bi-chevron-right"></i></button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center py-5 text-muted">
                        <div class="my-4 text-uppercase fw-semibold ticket-empty-state">
                            NO SE ENCONTRARON TICKETS REGISTRADOS
                        </div>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($tickets->hasPages()): ?>
    <div class="p-3 border-top">
        <?php echo e($tickets->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\tickets\index.blade.php ENDPATH**/ ?>