<?php $__env->startSection('title', 'Detalle de Licencia'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
        <i class="bi bi-key text-primary me-2"></i><?php echo e($licencia->nombre); ?>

    </h4>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('licencias.edit', $licencia)); ?>" class="btn btn-warning">
            <i class="bi bi-pencil me-1"></i>Editar
        </a>
        <a href="<?php echo e(route('licencias.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header bg-light fw-bold">Información de la Licencia</div>
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-sm-5 text-muted">Tipo:</dt>
                    <dd class="col-sm-7"><?php echo e($licencia->tipo_licencia); ?></dd>

                    <dt class="col-sm-5 text-muted">Estado:</dt>
                    <dd class="col-sm-7">
                        <span class="badge bg-<?php echo e($licencia->estado === 'Activa' ? 'success' : ($licencia->estado === 'Suspendida' ? 'warning' : 'danger')); ?>">
                            <?php echo e($licencia->estado); ?>

                        </span>
                    </dd>

                    <dt class="col-sm-5 text-muted">Cupos:</dt>
                    <dd class="col-sm-7">
                        <span class="badge <?php echo e($licencia->cupos_disponibles > 0 ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($licencia->cupos_asignados); ?> / <?php echo e($licencia->cantidad_maxima); ?> Asignados
                        </span>
                    </dd>

                    <dt class="col-sm-5 text-muted">Inicio:</dt>
                    <dd class="col-sm-7"><?php echo e($licencia->fecha_inicio ? $licencia->fecha_inicio->format('d/m/Y') : 'N/A'); ?></dd>

                    <dt class="col-sm-5 text-muted">Vencimiento:</dt>
                    <dd class="col-sm-7 <?php echo e($licencia->fecha_vencimiento && $licencia->fecha_vencimiento->isPast() ? 'text-danger fw-bold' : ''); ?>">
                        <?php echo e($licencia->fecha_vencimiento ? $licencia->fecha_vencimiento->format('d/m/Y') : 'N/A'); ?>

                    </dd>
                </dl>
                <?php if($licencia->descripcion): ?>
                <hr>
                <div class="text-muted small"><strong>Descripción:</strong><br><?php echo e($licencia->descripcion); ?></div>
                <?php endif; ?>
                <?php if($licencia->observaciones): ?>
                <hr>
                <div class="text-muted small"><strong>Observaciones:</strong><br><?php echo e($licencia->observaciones); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-8">
        <ul class="nav nav-tabs" id="licenciaTabs" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link active" id="asignaciones-tab" data-bs-toggle="tab" data-bs-target="#asignaciones" type="button" role="tab">
                    <i class="bi bi-people me-1"></i>Asignaciones
                </button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link" id="historial-tab" data-bs-toggle="tab" data-bs-target="#historial" type="button" role="tab">
                    <i class="bi bi-clock-history me-1"></i>Historial
                </button>
            </li>
        </ul>
        <div class="tab-content border-start border-end border-bottom bg-white p-3 mb-4" id="licenciaTabsContent">
            <!-- Pestaña Asignaciones -->
            <div class="tab-pane fade show active" id="asignaciones" role="tabpanel">
                <?php if($licencia->asignaciones->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-sm align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Funcionario</th>
                                <th>Equipo</th>
                                <th>Fecha Asig.</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $licencia->asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asignacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($asignacion->funcionario ? $asignacion->funcionario->nombre_completo : 'N/A'); ?></td>
                                <td>
                                    <?php if($asignacion->equipo): ?>
                                        <a href="<?php echo e(route('equipos.show', $asignacion->equipo)); ?>" class="fw-medium text-decoration-none"><?php echo e($asignacion->equipo->placa ?? $asignacion->equipo->nombre_equipo ?? 'Ver Equipo'); ?></a><br>
                                        <span class="text-muted small">Serial: <?php echo e($asignacion->equipo->serial ?? 'N/A'); ?></span>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($asignacion->fecha_asignacion ? $asignacion->fecha_asignacion->format('d/m/Y') : 'N/A'); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($asignacion->estado === 'Activa' ? 'success' : 'secondary'); ?>">
                                        <?php echo e($asignacion->estado); ?>

                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <p class="text-muted mb-0">No hay asignaciones para esta licencia.</p>
                <?php endif; ?>
            </div>

            <!-- Pestaña Historial -->
            <div class="tab-pane fade" id="historial" role="tabpanel">
                <?php if($historial->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-hover table-sm">
                        <thead class="table-light">
                            <tr>
                                <th>Fecha</th>
                                <th>Usuario</th>
                                <th>Acción</th>
                                <th>Observación</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $historial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($log->fecha->format('d/m/Y H:i')); ?></td>
                                <td><?php echo e($log->usuario ? $log->usuario->name : 'Sistema'); ?></td>
                                <td><?php echo e($log->accion); ?></td>
                                <td><?php echo e($log->observacion); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <p class="text-muted mb-0">No hay historial registrado.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\licencias\show.blade.php ENDPATH**/ ?>