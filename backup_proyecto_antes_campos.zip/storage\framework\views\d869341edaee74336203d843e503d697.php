<?php $__env->startSection('title', 'Importar Equipos'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex align-items-center justify-content-between mb-4">
    <div>
        <h2 class="mb-0 fw-bold"><i class="bi bi-file-earmark-arrow-up me-2 equipo-text-primary"></i>Importar Equipos desde Excel</h2>
        <p class="text-muted mb-0 mt-1">Sube un archivo <strong>.xlsx</strong> o <strong>.xls</strong> para registrar equipos en masa.</p>
    </div>
    <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Volver
    </a>
</div>


<?php if(session()->has('import_insertados')): ?>
    <?php
        $insertados    = session('import_insertados');
        $omitidos      = session('import_omitidos', 0);
        $failures      = session('import_failures', []);
        $importErrors  = session('import_errors', []);
        $columnReport  = session('import_column_report', []);
        $fallidas      = count($failures) + count($importErrors);
        $total         = $insertados + $fallidas + $omitidos;
    ?>

    
    <?php if(!empty($columnReport['formato'])): ?>
        <div class="alert <?php echo e($columnReport['formato'] === 'cmdb' ? 'alert-info' : ($columnReport['formato'] === 'propio' ? 'alert-success' : 'alert-warning')); ?> d-flex align-items-center mb-3">
            <i class="bi bi-magic me-2 fs-5"></i>
            <div>
                <strong>Formato detectado:</strong>
                <?php if($columnReport['formato'] === 'cmdb'): ?>
                    <span class="badge bg-info text-dark">CMDB Corporativo</span>
                <?php elseif($columnReport['formato'] === 'propio'): ?>
                    <span class="badge bg-success">Formato Propio del Sistema</span>
                <?php else: ?>
                    <span class="badge bg-warning text-dark">Formato Desconocido</span>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm text-center py-3">
                <div class="fs-1 fw-bold text-secondary"><?php echo e($total); ?></div>
                <div class="text-muted small">Filas procesadas</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm text-center py-3 border-success">
                <div class="fs-1 fw-bold text-success"><?php echo e($insertados); ?></div>
                <div class="text-muted small">Registradas</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm text-center py-3">
                <div class="fs-1 fw-bold text-warning"><?php echo e($omitidos); ?></div>
                <div class="text-muted small">Periféricos omitidos</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card border-0 shadow-sm text-center py-3 <?php echo e($fallidas > 0 ? 'border-danger' : ''); ?>">
                <div class="fs-1 fw-bold <?php echo e($fallidas > 0 ? 'text-danger' : 'text-muted'); ?>"><?php echo e($fallidas); ?></div>
                <div class="text-muted small">Con errores</div>
            </div>
        </div>
    </div>

    
    <?php if(!empty($columnReport)): ?>
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white fw-semibold border-bottom py-3">
                <i class="bi bi-layout-three-columns me-2 equipo-text-primary"></i>Reporte de Columnas
                <button class="btn btn-sm btn-outline-secondary float-end" type="button" data-bs-toggle="collapse" data-bs-target="#colReporte">
                    <i class="bi bi-chevron-down"></i>
                </button>
            </div>
            <div class="collapse" id="colReporte">
                <div class="card-body">
                    <div class="row g-3">
                        
                        <div class="col-md-4">
                            <h6 class="text-success fw-bold mb-2">
                                <i class="bi bi-check-circle-fill me-1"></i>
                                Reconocidas (<?php echo e(count($columnReport['reconocidas'] ?? [])); ?>)
                            </h6>
                            <?php if(!empty($columnReport['reconocidas'])): ?>
                                <div class="table-responsive" style="max-height: 250px; overflow-y: auto;">
                                    <table class="table table-sm table-borderless mb-0 small">
                                        <thead class="table-light">
                                            <tr>
                                                <th>Campo</th>
                                                <th>Columna Excel</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $columnReport['reconocidas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><code><?php echo e($col['campo_interno']); ?></code></td>
                                                    <td class="text-muted"><?php echo e($col['columna_excel']); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p class="text-muted small">Ninguna</p>
                            <?php endif; ?>
                        </div>

                        
                        <div class="col-md-4">
                            <h6 class="text-secondary fw-bold mb-2">
                                <i class="bi bi-dash-circle me-1"></i>
                                Ignoradas (<?php echo e(count($columnReport['ignoradas'] ?? [])); ?>)
                            </h6>
                            <?php if(!empty($columnReport['ignoradas'])): ?>
                                <div style="max-height: 250px; overflow-y: auto;">
                                    <?php $__currentLoopData = $columnReport['ignoradas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge bg-light text-dark border me-1 mb-1"><?php echo e($col); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php else: ?>
                                <p class="text-muted small">Ninguna</p>
                            <?php endif; ?>
                        </div>

                        
                        <div class="col-md-4">
                            <h6 class="text-warning fw-bold mb-2">
                                <i class="bi bi-exclamation-triangle me-1"></i>
                                Faltantes (<?php echo e(count($columnReport['faltantes'] ?? [])); ?>)
                            </h6>
                            <?php if(!empty($columnReport['faltantes'])): ?>
                                <div style="max-height: 250px; overflow-y: auto;">
                                    <?php $__currentLoopData = $columnReport['faltantes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="badge bg-warning-subtle text-warning-emphasis me-1 mb-1"><?php echo e($campo); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <p class="text-muted small mt-2">Se usarán valores por defecto para estos campos.</p>
                            <?php else: ?>
                                <p class="text-success small"><i class="bi bi-check me-1"></i>Todos los campos fueron encontrados.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    
    <?php if(count($failures) > 0): ?>
        <div class="card border-danger mb-4 shadow-sm">
            <div class="card-header bg-danger text-white fw-bold">
                <i class="bi bi-exclamation-triangle-fill me-2"></i>Filas con errores de validación
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-sm table-striped mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="equipo-import-col-fila">Fila #</th>
                                <th>Motivo</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $failures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="fw-bold text-danger"><?php echo e($f['fila']); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $f['errores']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="badge bg-danger-subtle text-danger-emphasis me-1 mb-1"><?php echo e($err); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>

    
    <?php if(count($importErrors) > 0): ?>
        <div class="card border-warning mb-4 shadow-sm">
            <div class="card-header bg-warning text-dark fw-bold">
                <i class="bi bi-bug-fill me-2"></i>Errores inesperados durante la importación
            </div>
            <ul class="list-group list-group-flush">
                <?php $__currentLoopData = $importErrors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item text-muted small"><?php echo e($e['mensaje']); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
<?php endif; ?>


<div class="card shadow-sm border-0">
    <div class="card-header bg-white fw-semibold border-bottom py-3">
        <i class="bi bi-upload me-2 equipo-text-primary"></i>Seleccionar archivo Excel
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('equipos.importar')); ?>" method="POST" enctype="multipart/form-data" id="formImportar">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label for="archivo" class="form-label fw-semibold">Archivo Excel <span class="text-danger">*</span></label>
                <input type="file"
                       class="form-control <?php $__errorArgs = ['archivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       id="archivo"
                       name="archivo"
                       accept=".xlsx,.xls"
                       required>
                <?php $__errorArgs = ['archivo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-text text-muted">Formatos admitidos: <strong>.xlsx</strong>, <strong>.xls</strong>. Tamaño máximo: 10 MB.</div>
            </div>

            <div class="alert alert-light border mb-4">
                <p class="fw-semibold mb-2 equipo-text-primary">
                    <i class="bi bi-magic me-1"></i>
                    El sistema detecta automáticamente el formato del archivo (CMDB corporativo o formato propio).
                </p>
                <div class="row g-3">
                    <div class="col-md-4">
                        <p class="fw-semibold mb-1 small equipo-text-primary"><i class="bi bi-laptop-fill me-1"></i>Equipo</p>
                        <table class="table table-sm table-borderless mb-0 small">
                            <tbody>
                                <tr><td><code>tipo_recurso</code></td><td class="text-muted">TIPO DE RECURSO</td></tr>
                                <tr><td><code>serial</code></td><td class="text-muted">SERIAL</td></tr>
                                <tr><td><code>placa</code></td><td class="text-muted">PLACA</td></tr>
                                <tr><td><code>marca</code></td><td class="text-muted">MARCA, MARCA EQUIPO</td></tr>
                                <tr><td><code>modelo</code></td><td class="text-muted">MODELO</td></tr>
                                <tr><td><code>nombre_equipo</code></td><td class="text-muted">NOMBRE DE EQUIPO</td></tr>
                                <tr><td><code>estado_operativo</code></td><td class="text-muted">ESTADO OPERATIVO</td></tr>
                                <tr><td><code>procesador</code></td><td class="text-muted">PROCESADOR</td></tr>
                                <tr><td><code>ram</code></td><td class="text-muted">MEMORIA RAM</td></tr>
                                <tr><td><code>disco</code></td><td class="text-muted">TAMAÑO DISCO DURO</td></tr>
                                <tr><td><code>sistema_operativo</code></td><td class="text-muted">SISTEMA OPERATIVO</td></tr>
                                <tr><td><code>fecha_compra</code></td><td class="text-muted">FECHA DE COMPRA</td></tr>
                                <tr><td><code>fin_garantia</code></td><td class="text-muted">FIN DE GARANTÍA</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-4">
                        <p class="fw-semibold mb-1 small equipo-text-primary"><i class="bi bi-person-fill me-1"></i>Usuario asignado</p>
                        <table class="table table-sm table-borderless mb-0 small">
                            <tbody>
                                <tr><td><code>nombre</code></td><td class="text-muted">NOMBRES Y APELLIDOS</td></tr>
                                <tr><td><code>cedula</code></td><td class="text-muted">CÉDULA DEL FUNCIONARIO</td></tr>
                                <tr><td><code>empresa_propietaria</code></td><td class="text-muted">EMPRESA PROPIETARIO</td></tr>
                                <tr><td><code>dependencia</code></td><td class="text-muted">Departamento</td></tr>
                                <tr><td><code>fuente_recurso</code></td><td class="text-muted">FUENTE DE RECURSO</td></tr>
                                <tr><td><code>empresa_funcionario</code></td><td class="text-muted">EMPRESA FUNCIONARIO</td></tr>
                                <tr><td><code>tipo_vinculacion</code></td><td class="text-muted">EMPLEADO O CONTRATISTA</td></tr>
                                <tr><td><code>shortname</code></td><td class="text-muted">SHORTNAME</td></tr>
                                <tr><td><code>departamento</code></td><td class="text-muted">DEPARTAMENTO</td></tr>
                                <tr><td><code>ciudad</code></td><td class="text-muted">Ciudad</td></tr>
                                <tr><td><code>cargo</code></td><td class="text-muted">CARGO</td></tr>
                                <tr><td><code>area</code></td><td class="text-muted">Área</td></tr>
                                <tr><td><code>piso</code></td><td class="text-muted">UBICACIÓN Y PISO</td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="col-md-4">
                        <p class="fw-semibold mb-1 small text-warning-emphasis"><i class="bi bi-slash-circle me-1"></i>Se ignoran automáticamente</p>
                        <ul class="list-unstyled small text-muted mb-3">
                            <li>Filas con <code>tipo_recurso</code> que contenga:</li>
                            <li class="ms-2">• <em>telefono</em></li>
                            <li class="ms-2">• <em>teclado</em></li>
                            <li class="ms-2">• <em>mouse</em></li>
                            <li class="ms-2">• <em>camara</em></li>
                            <li class="mt-1">Filas completamente vacías</li>
                            <li>Seriales duplicados (se actualizan)</li>
                        </ul>
                        <p class="fw-semibold mb-1 small text-success-emphasis"><i class="bi bi-check2-circle me-1"></i>Normalización automática</p>
                        <ul class="list-unstyled small text-muted mb-0">
                            <li>Mayúsculas, acentos, espacios → sin problema</li>
                            <li>Serial vacío → <code>SIN_SERIAL_xxx</code></li>
                            <li>Marca vacía → <code>Sin Marca</code></li>
                            <li>Nombre vacío → <code>Sin Asignar</code></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-lg text-white equipo-bg-primary" id="btnImportar">
                    <i class="bi bi-cloud-upload me-2"></i>Importar Excel
                </button>
                <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-lg btn-outline-secondary">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.getElementById('formImportar').addEventListener('submit', function () {
    const btn = document.getElementById('btnImportar');
    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Procesando...';
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\equipos\importar.blade.php ENDPATH**/ ?>