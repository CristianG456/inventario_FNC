<?php $__env->startSection('title', 'Historial Técnico — ' . $equipo->nombre_equipo); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">
            <i class="bi bi-tools me-2 text-warning"></i>Historial Técnico
        </h4>
        <small class="text-muted"><?php echo e($equipo->nombre_equipo); ?> — Serial: <?php echo e($equipo->serial); ?></small>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('historial-tecnico.create', ['equipo_id' => $equipo->id])); ?>"
           class="btn btn-primary">
            <i class="bi bi-plus-lg me-1"></i>Nuevo Evento
        </a>
        <a href="<?php echo e(route('equipos.show', $equipo)); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<?php if($registros->isEmpty()): ?>
    <div class="card border-0 shadow-sm">
        <div class="card-body text-center py-5 text-muted">
            <i class="bi bi-tools fs-2 d-block mb-2"></i>
            No hay eventos técnicos registrados para este equipo.
        </div>
    </div>
<?php else: ?>


<div class="card border-0 shadow-sm">
    <div class="card-header bg-white border-bottom py-3 d-flex align-items-center justify-content-between">
        <span><i class="bi bi-clock-history me-2 text-warning"></i><strong>Timeline de Eventos Técnicos</strong></span>
        <span class="badge bg-warning text-dark"><?php echo e($registros->count()); ?> eventos</span>
    </div>
    <div class="card-body py-4">
        <div class="timeline-container">
            <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex gap-3 mb-4 position-relative">
                <?php if(!$loop->last): ?>
                <div class="timeline-line"></div>
                <?php endif; ?>

                
                <div class="flex-shrink-0">
                    <div class="rounded-circle bg-<?php echo e($registro->tipo_evento_color); ?> bg-opacity-15 border border-<?php echo e($registro->tipo_evento_color); ?> d-flex align-items-center justify-content-center shadow-sm timeline-icon-box">
                        <i class="bi <?php echo e($registro->tipo_evento_icono); ?> text-<?php echo e($registro->tipo_evento_color); ?>"></i>
                    </div>
                </div>

                
                <div class="flex-grow-1">
                    <div class="card border-<?php echo e($registro->tipo_evento_color); ?> border-opacity-25 shadow-sm">
                        <div class="card-body py-3 px-3">
                            
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <span class="badge bg-<?php echo e($registro->tipo_evento_color); ?> me-2">
                                        <?php echo e($registro->tipo_evento_label); ?>

                                    </span>
                                    <strong><?php echo e($registro->descripcion); ?></strong>
                                </div>
                                <small class="text-muted text-nowrap ms-2">
                                    <i class="bi bi-calendar2 me-1"></i>
                                    <?php echo e($registro->fecha_evento?->format('d \d\e F \d\e Y')); ?>

                                </small>
                            </div>

                            
                            <?php if($registro->motivo): ?>
                            <p class="text-muted small mb-2">
                                <i class="bi bi-chat-left-dots me-1"></i>
                                <strong>Motivo:</strong> <?php echo e($registro->motivo); ?>

                            </p>
                            <?php endif; ?>

                            
                            <p class="mb-2 small">
                                <i class="bi bi-person-fill me-1 text-muted"></i>
                                <strong>Responsable:</strong> <?php echo e($registro->usuario_responsable); ?>

                            </p>

                            
                            <?php if($registro->usuario_asignado_snapshot): ?>
                            <div class="bg-light rounded p-2 mb-2 small">
                                <i class="bi bi-person-check me-1 text-success"></i>
                                <strong>Usuario asignado en ese momento:</strong>
                                <?php echo e($registro->usuario_asignado_snapshot['nombre'] ?? '—'); ?>

                                (CC: <?php echo e($registro->usuario_asignado_snapshot['cedula'] ?? '—'); ?>)
                                <?php if(!empty($registro->usuario_asignado_snapshot['area'])): ?>
                                    — Área: <?php echo e($registro->usuario_asignado_snapshot['area']); ?>

                                <?php endif; ?>
                            </div>
                            <?php endif; ?>

                            
                            <?php if($registro->observaciones): ?>
                            <p class="text-muted small mb-2">
                                <i class="bi bi-journal-text me-1"></i><?php echo e($registro->observaciones); ?>

                            </p>
                            <?php endif; ?>

                            
                            <?php if($registro->archivos && count($registro->archivos) > 0): ?>
                            <div class="mb-2">
                                <?php $__currentLoopData = $registro->archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(asset('storage/' . $archivo['ruta'])); ?>"
                                   target="_blank"
                                   class="btn btn-sm btn-outline-secondary me-1">
                                    <i class="bi bi-paperclip me-1"></i><?php echo e($archivo['nombre']); ?>

                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>

                            
                            <div class="d-flex gap-2 mt-2">
                                <a href="<?php echo e(route('historial-tecnico.show', $registro)); ?>"
                                   class="btn btn-sm btn-outline-info">
                                    <i class="bi bi-eye me-1"></i>Ver
                                </a>
                                <a href="<?php echo e(route('historial-tecnico.edit', $registro)); ?>"
                                   class="btn btn-sm btn-outline-warning">
                                    <i class="bi bi-pencil me-1"></i>Editar
                                </a>
                                <button type="button"
                                        class="btn btn-sm btn-outline-danger"
                                        data-delete-url="<?php echo e(route('historial-tecnico.destroy', $registro)); ?>"
                                        data-delete-name="el evento del <?php echo e($registro->fecha_evento?->format('d/m/Y')); ?>">
                                    <i class="bi bi-trash me-1"></i>Eliminar
                                </button>
                                <small class="text-muted ms-auto align-self-center">
                                    Registrado por: <?php echo e($registro->registradoPor?->name ?? '—'); ?>

                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\historial_tecnico\por_equipo.blade.php ENDPATH**/ ?>