<?php $__env->startSection('title', 'Historial de Vida — ' . $equipo->nombre_equipo); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h4 class="fw-bold mb-0">
            <i class="bi bi-clock-history me-2 text-primary"></i>
            Historial de Vida
        </h4>
        <small class="text-muted"><?php echo e($equipo->nombre_equipo); ?> — Serial: <?php echo e($equipo->serial); ?></small>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('equipos.show', $equipo)); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver al equipo
        </a>
    </div>
</div>


<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="rounded-circle bg-success bg-opacity-15 d-flex align-items-center justify-content-center equipo-historial-icon">
                    <i class="bi bi-person-fill text-success fs-5"></i>
                </div>
                <div>
                    <div class="fw-bold fs-5"><?php echo e($eventos->where('tipo', 'asignacion')->count()); ?></div>
                    <div class="text-muted small">Eventos de asignación</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="rounded-circle bg-warning bg-opacity-15 d-flex align-items-center justify-content-center equipo-historial-icon">
                    <i class="bi bi-tools text-warning fs-5"></i>
                </div>
                <div>
                    <div class="fw-bold fs-5"><?php echo e($eventos->where('tipo', 'tecnico')->count()); ?></div>
                    <div class="text-muted small">Eventos técnicos</div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body d-flex align-items-center gap-3">
                <div class="rounded-circle bg-info bg-opacity-15 d-flex align-items-center justify-content-center equipo-historial-icon">
                    <i class="bi bi-shield-check text-info fs-5"></i>
                </div>
                <div>
                    <div class="fw-bold fs-5"><?php echo e($eventos->where('tipo', 'administrativo')->count()); ?></div>
                    <div class="text-muted small">Cambios administrativos</div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="card border-0 shadow-sm">
    <div class="card-header bg-white border-bottom d-flex align-items-center gap-2 py-3">
        <i class="bi bi-clock-history text-primary"></i>
        <strong>Línea de Tiempo Completa</strong>
        <span class="badge bg-secondary ms-auto"><?php echo e($eventos->count()); ?> eventos</span>
    </div>
    <div class="card-body">
        <?php if($eventos->isEmpty()): ?>
            <div class="text-center py-5 text-muted">
                <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                No hay eventos registrados para este equipo.
            </div>
        <?php else: ?>
        <div class="timeline-container">
            <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $fecha = is_string($evento['fecha']) ? \Carbon\Carbon::parse($evento['fecha']) : $evento['fecha'];
            ?>
            <div class="timeline-item d-flex gap-3 mb-4 position-relative">
                
                <?php if(!$loop->last): ?>
                <div class="timeline-line"></div>
                <?php endif; ?>

                
                <div class="flex-shrink-0 position-relative z-1">
                    <div class="rounded-circle bg-<?php echo e($evento['color']); ?> bg-opacity-15 border border-<?php echo e($evento['color']); ?> d-flex align-items-center justify-content-center shadow-sm timeline-icon-box">
                        <i class="bi <?php echo e($evento['icono']); ?> text-<?php echo e($evento['color']); ?>"></i>
                    </div>
                </div>

                
                <div class="flex-grow-1">
                    <div class="card border-<?php echo e($evento['color']); ?> border-opacity-25 shadow-sm">
                        <div class="card-body py-3 px-3">
                            <div class="d-flex justify-content-between align-items-start mb-1">
                                <div>
                                    <span class="badge bg-<?php echo e($evento['color']); ?> bg-opacity-75 me-2">
                                        <?php echo e(ucfirst($evento['tipo'])); ?>

                                    </span>
                                    <strong class="fs-6"><?php echo e($evento['titulo']); ?></strong>
                                </div>
                                <small class="text-muted text-nowrap ms-2">
                                    <i class="bi bi-calendar2 me-1"></i>
                                    <?php echo e($fecha->format('d/m/Y')); ?>

                                    <?php if($evento['tipo'] === 'administrativo' || $evento['tipo'] === 'asignacion'): ?>
                                        <?php echo e($fecha->format('H:i')); ?>

                                    <?php endif; ?>
                                </small>
                            </div>

                            <?php if($evento['descripcion']): ?>
                            <p class="mb-1 text-secondary small"><?php echo e($evento['descripcion']); ?></p>
                            <?php endif; ?>

                            <?php if($evento['responsable']): ?>
                            <small class="text-muted">
                                <i class="bi bi-person me-1"></i><?php echo e($evento['responsable']); ?>

                            </small>
                            <?php endif; ?>

                            
                            <?php if($evento['tipo'] === 'asignacion' && $evento['modelo']->motivo): ?>
                            <div class="mt-1">
                                <small class="text-muted"><i class="bi bi-chat-left-text me-1"></i><?php echo e($evento['modelo']->motivo); ?></small>
                            </div>
                            <?php endif; ?>

                            
                            <div class="mt-2">
                                <?php if($evento['tipo'] === 'asignacion'): ?>
                                    <a href="<?php echo e(route('asignaciones.show', $evento['modelo']->id)); ?>"
                                       class="btn btn-sm btn-outline-<?php echo e($evento['color']); ?>">
                                        <i class="bi bi-eye me-1"></i>Ver detalle
                                    </a>
                                <?php elseif($evento['tipo'] === 'tecnico'): ?>
                                    <a href="<?php echo e(route('historial-tecnico.show', $evento['modelo']->id)); ?>"
                                       class="btn btn-sm btn-outline-<?php echo e($evento['color']); ?>">
                                        <i class="bi bi-eye me-1"></i>Ver detalle
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\equipos\historial_vida.blade.php ENDPATH**/ ?>