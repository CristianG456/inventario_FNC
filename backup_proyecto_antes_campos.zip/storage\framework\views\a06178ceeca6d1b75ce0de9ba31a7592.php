<?php $__env->startSection('title', 'Detalle del Equipo'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
        <i class="bi bi-info-circle me-2 text-info"></i><?php echo e($equipo->nombre_equipo); ?>

        <span class="badge bg-<?php echo e($equipo->estado_badge); ?> ms-2 fs-6"><?php echo e($equipo->estado_label); ?></span>
    </h4>
    <div class="d-flex gap-2 flex-wrap">
        <a href="<?php echo e(route('equipos.historial-vida', $equipo)); ?>" class="btn btn-outline-primary">
            <i class="bi bi-clock-history me-1"></i>Historial de Vida
        </a>
        <a href="<?php echo e(route('historial-tecnico.por-equipo', $equipo)); ?>" class="btn btn-outline-warning">
            <i class="bi bi-tools me-1"></i>Historial Técnico
        </a>
        <a href="<?php echo e(route('asignaciones.por-equipo', $equipo)); ?>" class="btn btn-outline-success">
            <i class="bi bi-person-fill-gear me-1"></i>Asignaciones
        </a>
        <a href="<?php echo e(route('equipos.edit', $equipo)); ?>" class="btn btn-warning text-white">
            <i class="bi bi-pencil me-1"></i>Editar
        </a>
        <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left me-1"></i>Volver
        </a>
    </div>
</div>

<div class="row g-4">
    
    <div class="col-lg-6">
        <div class="card h-100 border-0 shadow-sm">
            <div class="card-header bg-primary bg-opacity-10 fw-semibold border-0 py-3">
                <i class="bi bi-laptop me-2 text-primary"></i>Datos del Equipo
            </div>
            <div class="card-body">
                <dl class="row mb-0">
                    <dt class="col-sm-5 text-muted">Tipo</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->tipoRecurso?->nombre ?? '—'); ?></dd>
                    <dt class="col-sm-5 text-muted">Serial</dt>
                    <dd class="col-sm-7 font-monospace"><?php echo e($equipo->serial); ?></dd>
                    <dt class="col-sm-5 text-muted">Activo Fijo</dt>
                    <dd class="col-sm-7 font-monospace fw-bold text-dark"><?php echo e($equipo->activo_fijo ?? '—'); ?></dd>
                    <dt class="col-sm-5 text-muted">Placa</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->placa ?? '—'); ?></dd>
                    <dt class="col-sm-5 text-muted">Marca</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->marca); ?></dd>
                    <dt class="col-sm-5 text-muted">Modelo</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->modelo); ?></dd>
                    <dt class="col-sm-5 text-muted">Procesador</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->procesador ?? '—'); ?></dd>
                    <dt class="col-sm-5 text-muted">RAM</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->ram ?? '—'); ?></dd>
                    <dt class="col-sm-5 text-muted">Disco</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->disco ?? '—'); ?></dd>
                    <dt class="col-sm-5 text-muted">Sistema Op.</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->sistema_operativo ?? '—'); ?></dd>
                    <dt class="col-sm-5 text-muted">Fecha Compra</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->fecha_compra?->format('d/m/Y') ?? '—'); ?></dd>
                    <dt class="col-sm-5 text-muted">Fin Garantía</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->fin_garantia?->format('d/m/Y') ?? '—'); ?></dd>
                    <dt class="col-sm-5 text-muted">Tiempo de Uso</dt>
                    <dd class="col-sm-7"><?php echo e($equipo->tiempo_uso ?? '—'); ?></dd>
                    <?php if($equipo->razon_estado): ?>
                        <dt class="col-sm-5 text-muted">Razón Estado</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->razon_estado); ?></dd>
                    <?php endif; ?>
                </dl>
            </div>
        </div>
    </div>

    
    <div class="col-lg-6">
        <div class="card mb-4 border-0 shadow-sm">
            <div class="card-header bg-success bg-opacity-10 fw-semibold border-0 py-3 d-flex justify-content-between align-items-center">
                <span><i class="bi bi-person me-2 text-success"></i>Usuario Asignado</span>
                <?php if($equipo->usuarioAsignado): ?>
                    <span class="badge bg-success">Asignado</span>
                <?php else: ?>
                    <span class="badge bg-secondary">Sin asignar</span>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <?php if($equipo->usuarioAsignado): ?>
                    <dl class="row mb-0">
                        <dt class="col-sm-5 text-muted">Nombre</dt>
                        <dd class="col-sm-7 fw-bold"><?php echo e($equipo->usuarioAsignado->nombre); ?></dd>
                        <dt class="col-sm-5 text-muted">Cédula</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->cedula); ?></dd>
                        <dt class="col-sm-5 text-muted">Empresa Propietaria</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->empresa_propietaria ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Dependencia</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->dependencia ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Fuente de Recurso</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->fuente_recurso ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Empresa Funcionario</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->empresa_funcionario ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Emp. o Contratista</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->tipo_vinculacion ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Shortname</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->shortname ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Departamento</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->departamento ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Ciudad</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->ciudad ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Cargo</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->cargo ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Área</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->area ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Piso</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->usuarioAsignado->piso ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Distrito</dt>
                        <dd class="col-sm-7 fw-bold"><?php echo e($equipo->usuarioAsignado->distrito ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Seccional</dt>
                        <dd class="col-sm-7 fw-bold"><?php echo e($equipo->usuarioAsignado->seccional ?? '—'); ?></dd>
                    </dl>
                <?php else: ?>
                    <p class="text-muted mb-0">Sin usuario asignado.</p>
                <?php endif; ?>
            </div>
        </div>

        
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-warning bg-opacity-10 fw-semibold border-0 py-3">
                <i class="bi bi-usb-plug me-2 text-warning"></i>Periféricos
            </div>
            <div class="card-body">
                <?php if($equipo->periferico): ?>
                    <dl class="row mb-0">
                        <dt class="col-sm-5 text-muted">Teléfono Fijo</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->periferico->telefono ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Teclado</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->periferico->teclado ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Mouse</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->periferico->mouse ?? '—'); ?></dd>
                        <dt class="col-sm-5 text-muted">Cámara</dt>
                        <dd class="col-sm-7"><?php echo e($equipo->periferico->camara ?? '—'); ?></dd>
                    </dl>
                <?php else: ?>
                    <p class="text-muted mb-0">Sin periféricos registrados.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    
    <?php if($equipo->asignaciones->isNotEmpty()): ?>
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-success bg-opacity-10 fw-semibold border-0 py-3 d-flex justify-content-between align-items-center">
                <span><i class="bi bi-person-fill-gear me-2 text-success"></i>Últimas Asignaciones</span>
                <a href="<?php echo e(route('asignaciones.por-equipo', $equipo)); ?>"
                   class="btn btn-sm btn-outline-success">Ver todas</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-sm table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Tipo</th>
                                <th>Usuario</th>
                                <th>Fecha</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $equipo->asignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asig): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span class="badge bg-<?php echo e($asig->tipo_accion_color); ?>">
                                        <?php echo e($asig->tipo_accion_label); ?>

                                    </span>
                                </td>
                                <td class="small"><?php echo e($asig->usuario_nombre ?? '—'); ?></td>
                                <td class="small"><?php echo e($asig->fecha_accion?->format('d/m/Y')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
    <?php if($equipo->historialTecnico->isNotEmpty()): ?>
    <div class="col-lg-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-warning bg-opacity-10 fw-semibold border-0 py-3 d-flex justify-content-between align-items-center">
                <span><i class="bi bi-tools me-2 text-warning"></i>Últimos Eventos Técnicos</span>
                <a href="<?php echo e(route('historial-tecnico.por-equipo', $equipo)); ?>"
                   class="btn btn-sm btn-outline-warning">Ver todos</a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-sm table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Tipo</th>
                                <th>Descripción</th>
                                <th>Fecha</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $equipo->historialTecnico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ht): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span class="badge bg-<?php echo e($ht->tipo_evento_color); ?>">
                                        <i class="bi <?php echo e($ht->tipo_evento_icono); ?>"></i>
                                    </span>
                                </td>
                                <td class="small"><?php echo e(Str::limit($ht->descripcion, 50)); ?></td>
                                <td class="small"><?php echo e($ht->fecha_evento?->format('d/m/Y')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
    <?php if($equipo->licenciaAsignaciones && $equipo->licenciaAsignaciones->isNotEmpty()): ?>
    <div class="col-lg-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-info bg-opacity-10 fw-semibold border-0 py-3 d-flex justify-content-between align-items-center">
                <span><i class="bi bi-key me-2 text-info"></i>Licencias Asignadas</span>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-sm table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Licencia</th>
                                <th>Tipo</th>
                                <th>Fecha Asignación</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $equipo->licenciaAsignaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $la): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($la->licencia): ?>
                                        <a href="<?php echo e(route('licencias.show', $la->licencia)); ?>" class="text-decoration-none fw-medium">
                                            <?php echo e($la->licencia->nombre); ?>

                                        </a>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($la->licencia ? $la->licencia->tipo_licencia : 'N/A'); ?></td>
                                <td class="small"><?php echo e($la->fecha_asignacion?->format('d/m/Y')); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($la->estado === 'Activa' ? 'success' : 'secondary'); ?>">
                                        <?php echo e($la->estado); ?>

                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    
    <div class="col-12">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-secondary bg-opacity-10 fw-semibold border-0 py-3 d-flex justify-content-between align-items-center">
                <span><i class="bi bi-clipboard-check me-2 text-secondary"></i>Checklists Técnicos</span>
                <a href="<?php echo e(route('checklists.create')); ?>?equipo_id=<?php echo e($equipo->id); ?>"
                   class="btn btn-sm btn-outline-primary">
                    <i class="bi bi-plus-lg me-1"></i>Nuevo Checklist
                </a>
            </div>
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead>
                            <tr>
                                <th>Responsable TI</th>
                                <th>Orden de Trabajo</th>
                                <th>Resultado</th>
                                <th>FNC</th>
                                <th>Fecha</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $equipo->checklists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($cl->responsable_ti ?? '—'); ?></td>
                                    <td><?php echo e($cl->orden_trabajo ?? '—'); ?></td>
                                    <td><?php echo e($cl->resultado ?? '—'); ?></td>
                                    <td><?php echo e($cl->fnc ?? '—'); ?></td>
                                    <td><?php echo e($cl->created_at->format('d/m/Y')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('checklists.show', $cl)); ?>"
                                           class="btn btn-sm btn-outline-info">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('checklists.edit', $cl)); ?>"
                                           class="btn btn-sm btn-outline-warning">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">Sin checklists registrados.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\equipos\show.blade.php ENDPATH**/ ?>