<?php $__env->startSection('title', 'Gestión de Mantenimientos'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header mb-4">
    <div>
        <h4 class="page-title">Gestión de Mantenimientos</h4>
        <p class="page-subtitle">Vista global de todas las hojas de vida y soporte técnico (<?php echo e($registros->total()); ?> registros)</p>
    </div>
</div>

<div class="row g-4 mb-4">
    <div class="col-md-3">
        <div class="card p-4 d-flex flex-row align-items-center justify-content-between h-100 shadow-sm border-0">
            <div class="d-flex align-items-center gap-3">
                <div class="rounded-circle d-flex align-items-center justify-content-center maint-icon-wrapper maint-bg-info">
                    <i class="bi bi-file-earmark-plus fs-4"></i>
                </div>
                <div class="fw-bold text-muted small text-uppercase">Creados</div>
            </div>
            <div class="fs-3 fw-bold"><?php echo e($conteoCreados); ?></div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card p-4 d-flex flex-row align-items-center justify-content-between h-100 shadow-sm border-0">
            <div class="d-flex align-items-center gap-3">
                <div class="rounded-circle d-flex align-items-center justify-content-center maint-icon-wrapper maint-bg-purple">
                    <i class="bi bi-gear fs-4"></i>
                </div>
                <div class="fw-bold text-muted small text-uppercase">En Proceso</div>
            </div>
            <div class="fs-3 fw-bold"><?php echo e($conteoProceso); ?></div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card p-4 d-flex flex-row align-items-center justify-content-between h-100 shadow-sm border-0">
            <div class="d-flex align-items-center gap-3">
                <div class="rounded-circle d-flex align-items-center justify-content-center maint-icon-wrapper maint-bg-indigo">
                    <i class="bi bi-pause-circle fs-4"></i>
                </div>
                <div class="fw-bold text-muted small text-uppercase">Suspendidos</div>
            </div>
            <div class="fs-3 fw-bold"><?php echo e($conteosSuspendidos); ?></div>
        </div>
    </div>
    
    <div class="col-md-3">
        <div class="card p-4 d-flex flex-row align-items-center justify-content-between h-100 shadow-sm border-0">
            <div class="d-flex align-items-center gap-3">
                <div class="rounded-circle d-flex align-items-center justify-content-center maint-icon-wrapper maint-bg-success">
                    <i class="bi bi-check-circle fs-4"></i>
                </div>
                <div class="fw-bold text-muted small text-uppercase">Finalizados</div>
            </div>
            <div class="fs-3 fw-bold"><?php echo e($conteoFinalizados); ?></div>
        </div>
    </div>
</div>

<div class="card p-0">
    <div class="p-4 border-bottom border-light">
        <form action="<?php echo e(route('historial-tecnico.index')); ?>" method="GET" class="d-flex gap-3 align-items-center">
            <div class="search-bar flex-grow-1 maint-search-bar">
                <i class="bi bi-search text-muted"></i>
                <input type="text" name="buscar" value="<?php echo e(request('buscar')); ?>" placeholder="Busca por placa, descripción o caso...">
            </div>
            <button type="button" class="btn btn-outline-secondary rounded-pill px-4">
                <i class="bi bi-funnel me-1"></i> Más Filtros
            </button>
        </form>
    </div>
    
    <div class="table-responsive">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th class="ps-4">Activo</th>
                    <th>Tipo / Estado</th>
                    <th>Bitácora</th>
                    <th>Responsable</th>
                    <th>Fecha</th>
                    <th class="text-end pe-4">Acción</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="ps-4 fw-medium">
                        <?php echo e($reg->equipo->nombre_equipo ?? 'N/A'); ?>

                        <br><small class="text-muted"><?php echo e($reg->equipo->serial ?? ''); ?></small>
                    </td>
                    <td>
                        <span class="badge bg-light text-dark border"><?php echo e(\Str::title(str_replace('_', ' ', $reg->tipo_evento))); ?></span><br>
                        <span class="badge mt-1 <?php echo e($reg->estado == 'Finalizado' ? 'badge-success' : 
                            ($reg->estado == 'En proceso' ? 'badge-warning' : 
                            ($reg->estado == 'Suspendido' ? 'badge-danger' : 'badge-info'))); ?>"><?php echo e($reg->estado); ?></span>
                    </td>
                    <td class="text-muted maint-truncate-td">
                        <?php echo e($reg->descripcion); ?>

                    </td>
                    <td><?php echo e($reg->usuario_responsable); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($reg->fecha_evento)->format('d M Y')); ?></td>
                    <td class="text-end pe-4">
                        <a href="<?php echo e(route('historial-tecnico.show', $reg)); ?>" class="btn btn-sm btn-light rounded-circle"><i class="bi bi-eye"></i></a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center py-5 text-muted">
                        NO SE ENCONTRARON TICKETS REGISTRADOS
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($registros->hasPages()): ?>
    <div class="p-3 border-top">
        <?php echo e($registros->links()); ?>

    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\historial_tecnico\index.blade.php ENDPATH**/ ?>