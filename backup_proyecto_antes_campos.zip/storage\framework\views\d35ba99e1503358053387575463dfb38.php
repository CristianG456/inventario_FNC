

<?php $__env->startSection('title', 'Nuevo Equipo'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0">
        <i class="bi bi-plus-circle me-2 text-primary"></i>Registrar Nuevo Equipo
    </h4>
    <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i>Volver
    </a>
</div>

<form method="POST" action="<?php echo e(route('equipos.store')); ?>" novalidate id="formEquipo">
    <?php echo csrf_field(); ?>
    <?php $equipo = new \App\Models\Equipo(); ?>
    <?php echo $__env->make('equipos._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="d-flex justify-content-end gap-2 mt-2">
        <a href="<?php echo e(route('equipos.index')); ?>" class="btn btn-secondary">Cancelar</a>
        <button type="submit" class="btn btn-primary">
            <i class="bi bi-floppy me-1"></i>Guardar Equipo
        </button>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/equipos/create.blade.php ENDPATH**/ ?>