

<?php $__env->startSection('title', 'Tipos de Recurso'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h4 class="fw-bold mb-0"><i class="bi bi-tags me-2 text-primary"></i>Tipos de Recurso</h4>
    <a href="<?php echo e(route('tipo-recursos.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-lg me-1"></i>Nuevo Tipo
    </a>
</div>

<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nombre</th>
                        <th class="text-center">N&deg; Equipos</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tipoRecursos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-muted small"><?php echo e($tipo->id); ?></td>
                            <td class="fw-medium"><?php echo e($tipo->nombre); ?></td>
                            <td class="text-center">
                                <span class="badge bg-primary rounded-pill"><?php echo e($tipo->equipos_count); ?></span>
                            </td>
                            <td class="text-center">
                                <div class="btn-group btn-group-sm">
                                    <a href="<?php echo e(route('tipo-recursos.edit', $tipo)); ?>"
                                       class="btn btn-outline-warning" title="Editar">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <button type="button"
                                            class="btn btn-outline-danger"
                                            title="Eliminar"
                                            data-delete-url="<?php echo e(route('tipo-recursos.destroy', $tipo)); ?>"
                                            data-delete-name="<?php echo e($tipo->nombre); ?>"
                                            data-count="<?php echo e($tipo->equipos_count); ?>">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="text-center py-5 text-muted">
                                <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                                No hay tipos de recurso registrados.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if($tipoRecursos->hasPages()): ?>
        <div class="card-footer bg-white border-0">
            <?php echo e($tipoRecursos->links('pagination::bootstrap-5')); ?>

        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.inventario', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\inventario_equipos\resources\views\tipo_recursos\index.blade.php ENDPATH**/ ?>